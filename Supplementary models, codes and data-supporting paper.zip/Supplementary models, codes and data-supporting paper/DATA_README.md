# Data dictionary and processing conventions

This document describes the data supplied with **Data-driven learning of expert calibration for building energy simulation models** (manuscript BUIL-D-26-00739). Paths below are relative to the top-level `Supplementary models, codes and data` directory.

## Data organization

| Location | Contents and use |
|---|---|
| `full_data/data/simulation_data/` | Default cooling, heating, and total-energy matrices, with `simulation_index.csv`. Read by `full_data/src/preprocess_massive_csv.py`. |
| `cooling_only/data/simulation_data/` | Default cooling-energy matrix and its index. Read by `cooling_only/src/preprocess_massive_csv.py`. |
| `cooling_only/data/alternative_simulation_data/` | Separate cooling-energy matrix and index. The default preprocessing entry point does not select this directory. |
| Each workflow's `data/origin_data/` | Precomputed feature archive, parameter spreadsheet, initial IDF template, and weather inputs. |
| Each workflow's `data/generated_data/` | Supplied trained network weights and parameter-normalization metadata; also the destination for newly trained weights. |
| `Training_model.idf`, `Test_model.idf` | Additional root-level building model files. |

The default index files retain `NEW T.idf` in their `ModelFile` field; the alternative index retains `Office_Three_Floor.idf`. These are source identifiers recorded during simulation. Calibration entry points select their own `data/origin_data/initial.idf` template directly. Preserve the index identifiers as provenance rather than treating them as paths to the renamed root-level files.

## CSV layout and sample alignment

### Simulation matrices

The matrices are comma-separated text with a header row and 50,000 simulation-sample columns. There is no separate timestamp column. The inspected header and initial numeric rows each contain 50,000 fields.

| Matrix | Header convention |
|---|---|
| Default `cooling_energy.csv` in both workflows | Historical case labels, beginning with `案例_1`, `案例_2`, and `案例_3`. Later labels can contain prefixes, for example `5_案例_50000`. |
| Default `full_data/.../heating_energy.csv` and `total_energy.csv` | The same positional case-label convention as the default cooling matrix. |
| Alternative `cooling_energy.csv` | `SOBOL-000000` through `SOBOL-049999`. |

Each numeric row represents the next hourly position; each column represents one parameterized simulation. The supplied preprocessing entry points skip the header, consume the first **8,760 numeric rows**, and obtain parameter labels from the companion index. They do not parse a physical unit or date from the matrix header. Use these entry points for this release; the compatibility CSV loader in `common/data_processor.py` also supports a different legacy format with appended parameter rows.

### Simulation indexes

Each of the three `simulation_index.csv` files contains **50,000 records** and these 17 fields:

```text
#,Job_ID,WeatherFile,ModelFile,@@tag1@@,@@tag2@@,@@tag3@@,@@tag4@@,
@@tag5@@,@@tag6@@,@@tag7@@,@@tag8@@,@@tag9@@,@@tag10@@,
@@tag11@@,@@tag12@@,@@tag13@@
```

The line wrapping above is for readability. `#` is an index field; `Job_ID` runs from `SOBOL-000000` to `SOBOL-049999`; `WeatherFile` is `yubei.epw`; and the 13 tag fields hold the physical parameter values. The preprocessing scripts associate matrix column *j* with index record *j*. Keep all sample columns and index records in the same order. For the default matrices, do not derive this association by parsing historical case-label prefixes.

The `params` arrays in both supplied feature archives match the default index's 13 tag columns in record order after conversion to `float32`.

## Energy values and units

Three numerical representations occur in the package and should be distinguished when using the data:

1. **Stored matrix values.** The default bulk CSV matrices are consumed in their stored numerical scale; their headers contain no physical-unit field. Their preprocessing scripts perform sample-specific, channel-specific min-max normalization, not a conversion from a documented CSV unit to kWh. Use these matrices with the associated preprocessing and index files. A column name alone does not establish that a stored value is unscaled whole-building kWh or kWh per square metre.
2. **SQL-derived physical energy.** The supplied SQL extraction functions convert EnergyPlus energy values from joules to kWh by dividing by **3,600,000**. For example, `common_tools/extract_cooling_from_sobol.py` writes a `SOBOL-...` cooling matrix from `Zone2_Cooling_kWh`; this extractor returns kWh before area scaling. `common_tools/aggregate_cooling_sql_to_excel.py` also reports kWh. The calibration SQL functions define cooling, heating, and total-energy outputs in kWh before the following normalization.
3. **Calibration and network normalization.** The calibration scripts scale physical hourly kWh as `(kWh / AREA) / NORM_DIV`; current defaults are `AREA = 14203` square metres and `NORM_DIV = 0.2`. They subsequently apply independent min-max normalization for network feature construction. The resulting min-max features are dimensionless. Area scaling and min-max normalization are separate operations.

Keep the selected model's area and normalization settings consistent when supplying a new case. Some SQL helpers select numerical `ReportDataDictionaryIndex` values belonging to their associated model outputs; when using a different IDF, select the corresponding output variables and units from that simulation's SQL dictionary.

The alternative matrix is a separate data source and is not automatically substituted for the default matrix or its supplied feature archive.

## Parameter dictionary

The order is `P1` to `P13`, equivalent to `@@tag1@@` to `@@tag13@@`. Parameter meanings and units follow the tagged fields in the supplied IDFs. Bounds below are the observed sample bounds used in both supplied `delta_param_meta_*.npz` files; decimal values are shown without `float32` representation noise.

| ID | Parameter and IDF field | Minimum | Maximum | Sampled step | Unit |
|---|---|---:|---:|---:|---|
| P1 | Weekday cooling setpoint, temperature schedule value | 24 | 28 | 1 | degrees C |
| P2 | Weekday heating setpoint, temperature schedule value | 18 | 24 | 1 | degrees C |
| P3 | Lighting power per floor area, `Lights` | 11.5 | 19 | 1.5 | W/m2 |
| P4 | Infiltration flow per exterior surface area, `ZoneInfiltration:DesignFlowRate` with `Flow/ExteriorArea` | 0.0005 | 0.0015 | 0.0001 | m3/(s m2 of exterior surface) |
| P5 | Electric-equipment power per floor area, `ElectricEquipment` | 11 | 15 | 0.5 | W/m2 |
| P6 | Outdoor-air flow per person, `DesignSpecification:OutdoorAir` | 0.0075 | 0.0089 | 0.0002 | m3/(s person) |
| P7 | Occupancy density, `People` per floor area | 0.11 | 0.14 | 0.005 | person/m2 |
| P8 | Roof-material conductivity, `Material` named `ExtRoof` | 0.05 | 0.2 | 0.025 | W/(m K) |
| P9 | Exterior-wall-material conductivity, `Material` named `ExtWall` | 0.1 | 0.25 | 0.025 | W/(m K) |
| P10 | Window U-factor, `WindowMaterial:SimpleGlazingSystem` | 2.3 | 4.7 | 0.3 | W/(m2 K) |
| P11 | Weekend cooling setpoint, temperature schedule value | 24 | 28 | 1 | degrees C |
| P12 | Weekend heating setpoint, temperature schedule value | 18 | 24 | 1 | degrees C |
| P13 | Window solar heat gain coefficient, `WindowMaterial:SimpleGlazingSystem` | 0.2 | 0.8 | 0.05 | dimensionless |

For P3, the six sampled levels are `11.5, 13, 14.5, 16, 17.5, 19`; use the supplied maximum of 19 when restoring parameters from the trained models. P4 is normalized by **exterior surface area** in the IDFs. P8 and P9 are material conductivities rather than whole-assembly U-values. The exact weekday/weekend and occupied-hour behavior is defined by each template's schedule objects.

`parameter_ranges.xls` is an accompanying parameter spreadsheet. The supplied calibration scripts obtain normalization bounds from their `.npz` metadata, and training calculates bounds from the `params` array.

## NumPy archives and trained weights

Load `.npz` files with NumPy using `allow_pickle=False`.

| File and key | Shape | Stored dtype | Meaning |
|---|---|---|---|
| `cooling_only/data/origin_data/features_50k_cooling_only.npz`: `cooling_features` | `(50000, 222)` | `float64` | Normalized cooling features, 74 per season. |
| Same archive: `params` | `(50000, 13)` | `float32` | Physical parameter values in P1-P13 order. |
| `full_data/data/origin_data/features_50k_seasonal.npz`: `seasonal_features` | `(50000, 666)` | `float64` | Normalized cooling/heating/total features, 222 per season. |
| Same archive: `params` | `(50000, 13)` | `float32` | Physical parameter values in P1-P13 order. |
| Same archive: `heating_nz_ratio` | scalar `()` | `float64` | Fraction of nonzero heating entries computed by preprocessing; supplied value `0.26184752739726025`. Used to determine heating-loss weighting. |
| `cooling_only/data/generated_data/delta_param_meta_cooling_only.npz`: `p_min`, `p_max` | each `(13,)` | `float32` | Parameter-normalization bounds. |
| `full_data/data/generated_data/delta_param_meta_seasonal.npz`: `p_min`, `p_max` | each `(13,)` | `float32` | The same parameter-normalization bounds for the full-data model. |

The `.pth` files contain PyTorch model state dictionaries. Use `best_delta_model_cooling_only.pth` with `DeltaCorrectionModel(input_dim=3, output_dim=13)` and `best_delta_model_seasonal_converged.pth` with `DeltaCorrectionModel(input_dim=9, output_dim=13)`, as implemented in the corresponding `common/model.py` and calibration entry points.

## Feature order and training labels

Seasons are concatenated as **winter, transition, summer**:

- Winter: January, February, November, December.
- Transition: March, April, October.
- Summer: May through September.

Within each season, features concatenate 12 month-of-year bins, 7 day-of-week bins, 31 day-of-month bins, and 24 hour-of-day bins. Thus, the weekly scale means Monday-Sunday categories, and the daily scale means day-of-month categories, not consecutive weeks or consecutive days. Each bin stores a mean over the applicable season. A bin with no observations is set to zero.

For the full-data model, each bin contains channels in **cooling, heating, total-energy** order. Minima and maxima are calculated for each simulation sample and energy channel over its 8,760 input positions and shared across that sample's seasonal bins. A zero min-max denominator is replaced by 1.

The fixed grouping index in the preprocessing scripts is `pandas.date_range(start="2024-01-01", periods=8760, freq="h")`, running from 2024-01-01 00:00 to 2024-12-30 23:00. This is the algorithm's reference calendar; it is distinct from the 2025 timestamps in the supplied weather files. Retain this reference-index convention to reproduce the supplied feature construction.

Training first normalizes the physical parameters as:

```text
p_norm = (p_physical - p_min) / (p_max - p_min)
```

For a base sample `i` and a randomly selected target sample `j`, the learning inputs use `features[j] - features[i]` together with `p_norm[i]`. The supervised output is:

```text
delta_p = p_norm[j] - p_norm[i]
```

The 13 output values are differences expressed as fractions of each sampled parameter range, not absolute energy predictions or relative percentage changes from the base physical value. For example, a P1 correction of `+0.25` corresponds to `+1 degree C` before the iterative update-scaling factor is applied.

For a batch of size `B`, full-data network inputs have shapes `(B,12,9)`, `(B,7,9)`, `(B,31,9)`, and `(B,24,9)`; cooling-only inputs use 3 rather than 9 channels. Base-parameter and target-correction arrays each have shape `(B,13)`.

## Weather and measured-building inputs

Each workflow includes the author-supplied meteorological inputs `data/origin_data/weather.csv` and `data/origin_data/yubei.epw`. The CSV contains 8,760 records for 2025 and these fields:

```text
station_id,province,station_name,latitude,longitude,elevation_m,
year,month,day,hour,pressure_hpa,temperature_c,wind_speed_m_s,
wind_direction_deg,relative_humidity_pct,diffuse_radiation_w_m2,
direct_radiation_w_m2
```

Units are encoded in the field names: elevation in metres, pressure in hPa, temperature in degrees C, wind speed in m/s, wind direction in degrees, relative humidity in percent, and radiation in W/m2. CSV hours run from 0 to 23. The EPW has eight header lines followed by 8,760 weather records and uses hour fields from 1 to 24. Account for these different hour conventions when aligning or replacing weather inputs.

These meteorological files are boundary-condition inputs supplied with the models. Their existing source metadata and third-party rights are retained; the license for the authors' original synthetic simulation outputs does not relicense the meteorological source data. Use the repository's licensing statement and accompanying `LICENSE` for the applicable scope.

The measured cooling-energy file expected by the real-building scripts as `cooling_only/data/origin_data/Cooling.csv` is excluded. Only this real-data calibration branch requires user-supplied measured data. To match the included SQL conversion, supply hourly cooling energy in kWh per interval, align its 8,760 positions with the selected model, and use the appropriate area and normalization divisor. The virtual-ground-truth branches generate their target observations with EnergyPlus and do not require this confidential measured input.

When reusing the authors' code, models, or synthetic data, please cite the associated article and the repository record, and follow the applicable attribution requirements in `LICENSE`. The scholarly citation request does not add conditions to the MIT License.
