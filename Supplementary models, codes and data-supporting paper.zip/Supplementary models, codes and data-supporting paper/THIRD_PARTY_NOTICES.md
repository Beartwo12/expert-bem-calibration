# Third-party materials and provenance

The licenses in this package apply to rights held by the authors. They do not
replace third-party licenses or establish rights that the authors do not hold.

## Weather inputs

The following distributed input files are excluded from the package's new
CC BY 4.0 grant:

- `cooling_only/data/origin_data/weather.csv`
- `cooling_only/data/origin_data/yubei.epw`
- `full_data/data/origin_data/weather.csv`
- `full_data/data/origin_data/yubei.epw`

These are meteorological inputs, not synthetic building-energy output datasets.
Their original provider's rights and any applicable collection or redistribution
terms remain in force. The archive does not include a separate provider license
for these inputs. Contact the corresponding author through the associated paper
for provenance and permission information, and verify the original provider's
applicable redistribution terms before further redistribution. The weather
files have been retained unchanged.

## External software

EnergyPlus is an external dependency and is not bundled as an executable.
Obtain it from the official project and comply with its license and the terms
of its supporting resources: <https://energyplus.net/>.

PyTorch, NumPy, pandas, Matplotlib and openpyxl are external Python dependencies,
not copies licensed by this package. Their original licenses remain applicable.
Python standard-library modules and optional Tkinter or Excel readers retain
their respective licenses as well.

## Embedded or pre-existing material

Any third-party notices or component-specific terms retained inside a building
model or other distributed file continue to apply to those components. The
package licenses cover only the authors' licensable contributions.
